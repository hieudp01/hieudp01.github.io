function load_core( ... )
	local file = nx_resource_path() .. "auto9yin\\lua\\load_auto_core.lua"
	dofile(file)
	file = nx_resource_path() .. "auto9yin\\lua\\load_auto_main.lua"
	dofile(file)
end